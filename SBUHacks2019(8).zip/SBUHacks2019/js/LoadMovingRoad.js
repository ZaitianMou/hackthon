function buildMovingRoad(){
    let doc = document.getElementById("grass1");
    doc.classList.add("moving_road");
    doc.hidden=false;
    
    window.setTimeout(function(){
        let doc = document.getElementById("grass2");
        doc.classList.add("moving_road");
        doc.hidden=false;
    },5000);
    window.setTimeout(function(){
        let doc = document.getElementById("flower1");
        doc.classList.add("moving_road");
        doc.hidden=false;
    },9000);
    window.setTimeout(function(){
        let doc = document.getElementById("flower2");
        doc.classList.add("moving_road");
        doc.hidden=false;
    },19000);
    
}

