class SBUHacks2019_Controller{



	constructor (){

		this.registerEventHandler("welcome_page_start","click", this["processStartTyping"]);

	}

	registerEventHandler(id, eventName,callback){



		let control=document.getElementById(id);

		control.addEventListener(eventName,callback);
	}




	processStartTyping(){
		alert("Are you ready?");
	}


}