class Typing{
	
}